jQuery(document).ready(function($){
    
    /*** Lightbox ***/
    (function() {
        try{
            $('.magnific-pop').magnificPopup({
                type:'image'
            });
        } catch (ignore) {}
    })();

});